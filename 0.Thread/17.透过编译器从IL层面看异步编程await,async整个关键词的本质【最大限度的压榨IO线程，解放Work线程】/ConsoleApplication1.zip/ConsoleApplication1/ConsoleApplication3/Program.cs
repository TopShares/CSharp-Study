﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            MyHello();
        }

        static async Task<string> MyHello()
        {
            var x = await Task.Run(() =>
            {
                Console.WriteLine("i'm middle");

                return "i'm ok";
            });

            return "1";
        }
    }
}
