﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            var info = GetString().Result;

            Console.WriteLine(info);
        }

        static async Task<string> GetString()
        {
            FileStream fs = new FileStream(Environment.CurrentDirectory + "//1.txt", FileMode.Open);

            var bytes = new byte[fs.Length];

            var len = await fs.ReadAsync(bytes, 0, bytes.Length);

            var str = Encoding.Default.GetString(bytes);

            return str;
        }
    }
}
