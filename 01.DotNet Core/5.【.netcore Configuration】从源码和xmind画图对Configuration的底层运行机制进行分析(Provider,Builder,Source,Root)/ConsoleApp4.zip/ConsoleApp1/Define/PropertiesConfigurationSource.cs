﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1.Define
{
    public class PropertiesConfigurationSource : IConfigurationSource
    {

        private string path = string.Empty;
        public PropertiesConfigurationSource(string path)
        {
            this.path = path;
        }

        /// <summary>
        /// 生成Provider
        /// </summary>
        /// <param name="builder"></param>
        /// <returns></returns>
        public IConfigurationProvider Build(IConfigurationBuilder builder)
        {
            return new PropertiesConfigurationProvider(this.path);
        }
    }
}
