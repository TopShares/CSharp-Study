﻿using Polly;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading;

namespace ConsoleApp2
{
    public class TimeoutTest
    {
        public static void Run()
        {
            var cancellationToken = new CancellationToken();

            //10s后 cancellationToken过期
            var policy = Policy.Timeout(10);

            //通过cancellationToken进行传值，如果10s过去，IsCancellationRequested 自动变成取消状态
            policy.Execute((token) =>
            {
                for (int i = 0; i < 1000; i++)
                {
                    //大家需要根据这个状态来做具体的业务逻辑
                    Console.WriteLine(token.IsCancellationRequested);
                    System.Threading.Thread.Sleep(1000);
                }
            }, cancellationToken);

            Console.Read();
        }

        /// <summary>
        /// 获取页面内容
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public static string GetHtml(string url)
        {
            var html = string.Empty;

            Thread.Sleep(20);

            return html;
        }
    }
}
