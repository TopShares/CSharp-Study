﻿using Polly;
using System;
using System.Collections.Generic;
using System.Net;

namespace ConsoleApp2
{
    /// <summary>
    /// 回退操作
    /// </summary>
    public class FallbackTest
    {
        public static void Run()
        {
            var result = Policy<string>.Handle<WebException>()
                                    .Fallback(() =>
                                    {
                                        return "接口失败，这个fake的值给你！";
                                    })
                                    .Execute(() =>
                                    {
                                        return GetHtml("http://1cnblogs.com");
                                    });

            Console.WriteLine(result);

            Console.Read();
        }

        /// <summary>
        /// 获取页面内容
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public static string GetHtml(string url)
        {
            var html = string.Empty;

            try
            {
                var webClient = new WebClient();

                html = webClient.DownloadString(url);
            }
            catch (Exception ex)
            {
                throw;
            }

            return html;
        }
    }
}
