﻿using Polly;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    public class BulkheadTest
    {
        public static void Run()
        {
            var policy = Policy.Bulkhead(5, 1000);

            Parallel.For(0, 100, (i) =>
            {
                //这里只能做一次调用
                var result = policy.Execute<string>(() =>
                {
                    return GetHtml("http://cnblogs.com");
                });

                Console.WriteLine("已成功获取到数据:{0}", result);
            });


            Console.Read();
        }

        /// <summary>
        /// 获取页面内容
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public static string GetHtml(string url)
        {
            var html = string.Empty;

            try
            {
                var webClient = new WebClient();

                html = webClient.DownloadString(url);

                html = html.Substring(0, 17);

                Console.WriteLine($"当前线程ID={Thread.CurrentThread.ManagedThreadId}");

                System.Threading.Thread.Sleep(2000);
            }
            catch (Exception ex)
            {
                throw;
            }

            return html;
        }
    }
}
