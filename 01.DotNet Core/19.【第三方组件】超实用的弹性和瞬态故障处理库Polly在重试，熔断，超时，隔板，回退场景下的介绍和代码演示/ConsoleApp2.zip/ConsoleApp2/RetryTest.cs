﻿using Polly;
using System;
using System.Collections.Generic;
using System.Net;

namespace ConsoleApp2
{
    public class RetryTest
    {
        public static void Run()
        {
            //重试策略的设定
            var retryPolicy = Policy.Handle<WebException>()
                                    .WaitAndRetry(new List<TimeSpan>()
                                    {
                                        TimeSpan.FromSeconds(1),
                                        TimeSpan.FromSeconds(3),
                                        TimeSpan.FromSeconds(5)
                                    }, (ex, dt) =>
                                    {
                                        Console.WriteLine($"{DateTime.Now} {ex.Message}  {dt} ");
                                    });

            int count = 0;

            var html = retryPolicy.Execute(() =>
             {
                 var url = "http://1cnblogs.com";

                 if (count == 3) url = "http://cnblogs.com";

                 return GetHtml(url, ref count);
             });

            //这个是我调用第三次获取到的内容。。
            Console.WriteLine(html);
        }

        /// <summary>
        /// 获取页面内容
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public static string GetHtml(string url, ref int count)
        {
            var html = string.Empty;
            try
            {
                var webClient = new WebClient();

                html = webClient.DownloadString(url);
            }
            catch (Exception ex)
            {
                count++;
                throw;
            }

            return html;
        }
    }
}
