﻿using Polly;
using System;
using System.Collections.Generic;
using System.Net;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            FallbackTest.Run();

            Console.Read();
        }
    }
}
