﻿using Common;
using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using System.Collections;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            var tokenSource = new CancellationTokenSource();

            Task.Factory.StartNew(() =>
            {
                while (!tokenSource.IsCancellationRequested)
                {
                    Console.WriteLine($"{DateTime.Now} :业务逻辑处理中");
                    System.Threading.Thread.Sleep(1000);
                }
            }).ContinueWith(t =>
            {
                Console.WriteLine("服务安全退出！");
                Environment.Exit(0);  //强制退出
            });

            Console.WriteLine("服务成功开启!");

            while (!"Y".Equals(ConfigurationManager.Configuration["isquit"], StringComparison.OrdinalIgnoreCase))
                Thread.Sleep(1000);



            tokenSource.Cancel();
        }
    }
}
