using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {

            IConfiguration configuration = new ConfigurationBuilder().SetBasePath(Environment.CurrentDirectory)
                                                  .AddJsonFile($"appsettings.json", optional: true, reloadOnChange: true)
                                                                    //.AddXmlFile("appsettings.xml")

                                                                    //.AddEnvironmentVariables()
                                                                    .Build();
            //Rootobject rootobject = new Rootobject();
            //configuration.Bind(rootobject);

            var rootobject = configuration.Get<Rootobject>();

            var i = 10;

            var info = configuration.GetValue<int>("mysql:port", 0);

            //var info = configuration["mysql:port"];


            //var info = configuration["shopidlist:0:entid"];

            //shopidlist:0:entid
            //var info = configuration.GetSection("shopidlist").GetSection("1").GetSection("entid").Value;
            //var info = configuration.GetSection("shopidlist").GetSection("1")["entid"];

            //Console.WriteLine(info);
        }
    }
    public class Rootobject
    {
        public Mysql mysql { get; set; }
        public Shopidlist[] shopidlist { get; set; }
    }

    public class Mysql
    {
        public string host { get; set; }
        public int port { get; set; }
    }

    public class Shopidlist
    {
        public int entid { get; set; }
    }

}
