﻿using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Caching.Redis;
using System;
using System.Text;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            RedisCache redisCache = new RedisCache(new RedisCacheOptions()
            {
                Configuration = "192.168.23.167:6379",
                InstanceName = "test"
            });

            //在Redis中是用Hash的模式存放的。。
            redisCache.SetString("username", "jack", new DistributedCacheEntryOptions()
            {
                AbsoluteExpiration = DateTime.Now.AddDays(1),
            });

            var info = redisCache.GetString("username");

            Console.WriteLine($"{info}");
        }
    }
}
