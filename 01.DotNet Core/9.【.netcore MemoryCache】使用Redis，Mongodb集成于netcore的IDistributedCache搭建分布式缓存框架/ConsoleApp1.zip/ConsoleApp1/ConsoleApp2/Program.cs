﻿using Microsoft.Extensions.Caching.MongoDB;
using Microsoft.Extensions.Caching;
using Microsoft.Extensions.Caching.Distributed;
using System;
using System.Text;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            MongoDBCache mongoDBCache = new MongoDBCache(new MongoDBCacheOptions()
            {
                ConnectionString = "mongodb://192.168.23.167:27017",
                DatabaseName = "mydb",
                CollectionName = "mytest"
            });

            //mongoDBCache.Set("username", Encoding.UTF8.GetBytes("jack"), new Microsoft.Extensions.Caching.Distributed.DistributedCacheEntryOptions()
            //{
            //    AbsoluteExpiration = DateTime.Now.AddDays(1)
            //});

            mongoDBCache.SetString("username", "jack2", new Microsoft.Extensions.Caching.Distributed.DistributedCacheEntryOptions()
            {
                AbsoluteExpiration = DateTime.Now.AddDays(1)
            });

            var info = mongoDBCache.GetString("username");

            Console.WriteLine(info);
        }
    }
}
