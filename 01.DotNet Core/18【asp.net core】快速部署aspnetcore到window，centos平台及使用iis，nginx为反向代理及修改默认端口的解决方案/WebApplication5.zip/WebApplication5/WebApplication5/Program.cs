﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace WebApplication5
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateWebHostBuilder(args).Build().Run();
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args)
        {
            var builder = WebHost.CreateDefaultBuilder(args)
                  //.UseUrls("http://localhost:9000")
                  //.UseSetting("urls", "http://localhost:9001")
                  //.UseSetting(WebHostDefaults.ServerUrlsKey, "http://localhost:9001")
                  .UseStartup<Startup>();

            //var configuration = new ConfigurationBuilder().SetBasePath(Environment.CurrentDirectory)
            //                                            .AddJsonFile("hosts.json")
            //                                            .Build();

            //builder.UseConfiguration(configuration);

            return builder;
        }

    }
}
