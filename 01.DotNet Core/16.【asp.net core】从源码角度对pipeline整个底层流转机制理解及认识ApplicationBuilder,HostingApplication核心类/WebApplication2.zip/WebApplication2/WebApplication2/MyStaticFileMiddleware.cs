﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2
{
    public class MyStaticFileMiddleware
    {
        private readonly RequestDelegate _next;

        public MyStaticFileMiddleware(RequestDelegate next)
        {
            this._next = next;
        }

        /// <summary>
        /// Invoke 执行
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public Task Invoke(HttpContext context)
        {
            //1. logic  如果我当前的context的url中有jpg，那么就直接从文件中读取，否则往下传递
            var path = context.Request.Path.Value;

            if (path.Contains(".png"))
            {
                var mypath = path.TrimStart('/');
                return context.Response.SendFileAsync(mypath);
            }


            var task = this._next(context);

            return task;
        }
    }
}
