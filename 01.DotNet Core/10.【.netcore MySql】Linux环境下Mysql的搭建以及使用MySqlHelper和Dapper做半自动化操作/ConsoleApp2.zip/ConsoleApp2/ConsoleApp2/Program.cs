﻿using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using System;
using Dapper;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            var connectionString = "server=192.168.23.167;userid=root;pwd=DataMip@123;port=3306;database=datamip;SslMode=none;";

            //MySqlConnection mySqlConnection = new MySqlConnection(connectionString);

            //MySqlCommand

            ////Select 
            //var ds = MySqlHelper.ExecuteDataset(connectionString, "select * from users");

            //var info = JsonConvert.SerializeObject(ds);

            ////Update
            //var result = MySqlHelper.ExecuteNonQuery(connectionString, "update users set Email='3@qq.com' where UserID=1");

            //var reader = MySqlHelper.ExecuteReader(connectionString, "select * from users");

            //var users = new Users();

            //while (reader.Read())
            //{
            //    users.UserID = reader.GetInt32("UserID");
            //    users.UserNick = reader.GetString("UserNick");
            //    users.LoginIP = reader.GetString("LoginIP");
            //    users.Email = reader.GetString("Email");
            //}

            //reader.Close();

            MySqlConnection mySqlConnection = new MySqlConnection(connectionString);

            //var userList = mySqlConnection.Query<Users>("select * from users where UserID=@userid", new { userid = 2 });

            var nums = mySqlConnection.Execute("update users set Email=@email where UserID=@userid", new { userid = 2, email = "zzzz@qq.com" });
        }
    }

    class Users
    {
        public int UserID { get; set; }

        public string UserNick { get; set; }

        public string LoginIP { get; set; }

        public string Email { get; set; }
    }
}
