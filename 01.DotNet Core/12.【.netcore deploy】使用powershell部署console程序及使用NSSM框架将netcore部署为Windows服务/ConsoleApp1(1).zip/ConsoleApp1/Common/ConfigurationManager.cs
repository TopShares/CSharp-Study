﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Common
{
    public class ConfigurationManager
    {
        public static IConfigurationRoot Configuration
        {
            get
            {
                var configuration = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory())
                                                              .AddJsonFile(string.Format("appsettings.{0}.json",
                                                               Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")),
                                                               optional: true,
                                                               reloadOnChange: true)   //Watch监控
                                                               .AddJsonFile(string.Format("ops.{0}.json",
                                                               Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")),
                                                               optional: true,
                                                               reloadOnChange: true)
                                                             .Build();
                return configuration;
            }
        }
    }
}
