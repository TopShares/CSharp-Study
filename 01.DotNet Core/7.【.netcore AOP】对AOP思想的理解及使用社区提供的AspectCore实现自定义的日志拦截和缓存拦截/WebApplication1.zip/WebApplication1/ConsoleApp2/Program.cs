﻿using AspectCore.DynamicProxy;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Threading.Tasks;
using AspectCore.Extensions.DependencyInjection;
using System.Collections.Generic;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            //IOC容器
            ServiceCollection services = new ServiceCollection();

            //注册服务
            services.AddDynamicProxy();

            services.AddTransient<IMySql, MySql>();

            var provider = services.BuildAspectCoreServiceProvider();

            var mysql = provider.GetService<IMySql>();

            //走业务逻辑了
            var msg = mysql.GetData(10);

            Console.WriteLine(msg);

            //应该是直接走缓存了。。。
            msg = mysql.GetData(10);

            Console.WriteLine(msg);

            Console.Read();

        }
    }

    /// <summary>
    /// 日志切面
    /// </summary>
    public class MyLogInterceptorAttribute : AbstractInterceptorAttribute
    {
        public override Task Invoke(AspectContext context, AspectDelegate next)
        {
            Console.WriteLine("开始记录日志。。。。。");

            var task = next(context);

            Console.WriteLine("结束记录日志。。。。。");

            return task;
        }
    }

    /// <summary>
    /// 缓存切面
    /// </summary>
    public class MyCacheInterceptorAttribute : AbstractInterceptorAttribute
    {
        private Dictionary<string, string> cacheDict = new Dictionary<string, string>();

        public override Task Invoke(AspectContext context, AspectDelegate next)
        {
            //用id作为cacheKey
            var cacheKey = string.Join(",", context.Parameters);

            if (cacheDict.ContainsKey(cacheKey))
            {
                context.ReturnValue = cacheDict[cacheKey].ToString();

                return Task.CompletedTask;
            }

            var task = next(context);

            //ReturnValue 其实就是一个传递值的媒介
            var cacheValue = context.ReturnValue;

            cacheDict.Add(cacheKey, string.Format(" from Cache : {0}", cacheValue.ToString()));

            return task;
        }
    }



    public interface IMySql
    {
        string GetData(int id);
    }

    public class MySql : IMySql
    {
        //[MyLogInterceptor]
        [MyCacheInterceptor]
        public string GetData(int id)
        {
            var msg = $"已经获取到数据id={id}的数据";

            //Console.WriteLine(msg);

            return msg;
        }
    }
}
