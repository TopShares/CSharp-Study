﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            //IOC容器
            ServiceCollection services = new ServiceCollection();

            //注册服务

            //每次调用都new
            //services.AddTransient<IFly, Pig>();

            ////表示仅new一次
            services.AddSingleton<IFly, Pig>();

            ////在某一个作用域中只会new一次（单例）
            //services.AddScoped<IFly, Pig>();

            //注册服务
            services.AddLogging();

            var provider = services.BuildServiceProvider();

            var scope1 = provider.CreateScope();

            var scope2 = provider.CreateScope();

            scope1.ServiceProvider.GetService<IFly>();
            scope2.ServiceProvider.GetService<IFly>();

            //设置这个log 的输出地。。Console
            provider.GetService<ILoggerFactory>().AddConsole(LogLevel.Debug);

            //var fly = provider.GetService<IFly>();
            // fly = provider.GetService<IFly>();

            //fly.Fly();

            //var pig=new Pig();
        }
    }

    public interface IFly
    {
        void Fly();
    }

    public class Pig : IFly
    {
        //ILogger<Pig> logger = null;

        public Pig(ILoggerFactory loggerFactory)
        {
            Console.WriteLine("构造函数被调用");
            //logger = loggerFactory.CreateLogger<Pig>();
        }

        public void Fly()
        {
            //logger.LogInformation("这是console的日志。。。。");

            //Console.WriteLine("风口来了，猪都会飞！");
        }
    }
}
