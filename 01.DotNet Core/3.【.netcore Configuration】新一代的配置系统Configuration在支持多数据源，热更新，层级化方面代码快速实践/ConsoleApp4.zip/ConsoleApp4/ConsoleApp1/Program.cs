using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;

namespace ConsoleApp1
{
  class Program
  {
    static void Main(string[] args)
    {
      var initData = new List<KeyValuePair<string, string>>();

      initData.Add(new KeyValuePair<string, string>("username", "abcd"));


      IConfiguration configuration = new ConfigurationBuilder().SetBasePath(Environment.CurrentDirectory)
                                            .AddInMemoryCollection(initData)
                                            .AddJsonFile($"appsettings.json", optional: true, reloadOnChange: true)
                                                              //.AddXmlFile("appsettings.xml")

                                                              //.AddEnvironmentVariables()
                                                              .Build();

      while (true)
      {
        var info = configuration["username"];

        Console.WriteLine(info);

        System.Threading.Thread.Sleep(1000);
      }

      //Console.WriteLine("Hello World!");
    }
  }
}
