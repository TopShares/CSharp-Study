﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Transactions;

namespace Mytest
{
    //[ServiceBehavior]
    public class FlyService : IFlyService
    {

        public void Inovke(string msg)
        {
            Console.WriteLine("我是服务器执行方法Invoke");
        }
    }
}
