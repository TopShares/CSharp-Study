﻿using Mytest;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Xml;

public class Class1
{
    static void Main(string[] args)
    {
        ServiceHost host = new ServiceHost(typeof(FlyService));

        host.Description.Endpoints[0].EndpointBehaviors.Add(new MyEndpoint());

        host.Open();

        Console.WriteLine("WCF 服务开启");

        Console.Read();
    }

    public class MyDispatchMessageInspector : IDispatchMessageInspector
    {
        public object AfterReceiveRequest(ref Message request, IClientChannel channel, InstanceContext instanceContext)
        {
            //request：   在这里面，我们可以实现自定义的代码。

            var ip = request.Headers.GetHeader<string>("ip", string.Empty);

            var dt = request.Headers.GetHeader<string>("datetime", string.Empty);

            var token= request.Headers.GetHeader<string>("token", string.Empty);

            return request;
        }

        public void BeforeSendReply(ref Message reply, object correlationState)
        {
            //response：
        }
    }

    public class MyEndpoint : IEndpointBehavior
    {
        public void AddBindingParameters(ServiceEndpoint endpoint, BindingParameterCollection bindingParameters)
        {
        }

        public void ApplyClientBehavior(ServiceEndpoint endpoint, ClientRuntime clientRuntime)
        {

        }

        public void ApplyDispatchBehavior(ServiceEndpoint endpoint, EndpointDispatcher endpointDispatcher)
        {
            endpointDispatcher.DispatchRuntime.MessageInspectors.Add(new MyDispatchMessageInspector());
        }

        public void Validate(ServiceEndpoint endpoint)
        {

        }
    }
}






