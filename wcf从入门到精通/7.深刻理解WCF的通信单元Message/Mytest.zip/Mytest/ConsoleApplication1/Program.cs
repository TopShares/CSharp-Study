﻿
using Mytest;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            var factory = new ChannelFactory<IFlyService>(new BasicHttpBinding(), "http://169.254.72.29:8733/MyService/");

            var channel = factory.CreateChannel();

            //构造msg
            var msg = Message.CreateMessage(MessageVersion.Soap11, "http://tempuri.org/IFlyService/Inovke", "我给服务器发送信息");

            //在msg的header中增加参数
            msg.Headers.Add(MessageHeader.CreateHeader("dt", string.Empty, DateTime.Now));

            var rsp = channel.Inovke(msg);

            var result = rsp.GetBody<string>();

            Console.WriteLine(result);
        }
    }
}
