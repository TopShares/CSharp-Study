﻿
using ConsoleApplication1.ServiceReference2;
using Mytest;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {

            FlyServiceClient client = new FlyServiceClient();


            var message = client.Inovke("hello");

            Console.WriteLine("调用成功");

            Console.Read();
        }
    }
}
