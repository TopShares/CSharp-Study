﻿
using ConsoleApplication1.ServiceReference2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {

            FlyServiceClient client = new FlyServiceClient();

            var msg = Message.CreateMessage(MessageVersion.Soap11, "http://tempuri.org/IFlyService/Inovke", "我给服务器发送信息");

            var message = client.Inovke(msg);

            Console.WriteLine("调用成功");

            Console.Read();
        }
    }
}
