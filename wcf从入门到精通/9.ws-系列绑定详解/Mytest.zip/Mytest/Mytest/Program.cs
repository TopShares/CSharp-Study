﻿using Mytest;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

public class Class1
{
    static void Main(string[] args)
    {
        var basic = new BasicHttpBinding().CreateBindingElements();

        ServiceHost host = new ServiceHost(typeof(FlyService));

        host.Open();

        Console.WriteLine("WCF 服务开启");

        Console.Read();
    }
}
