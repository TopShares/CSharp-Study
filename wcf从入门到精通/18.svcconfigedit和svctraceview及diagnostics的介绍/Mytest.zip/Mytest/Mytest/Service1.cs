﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Transactions;

namespace Mytest
{
    public class FlyService : IFlyService
    {
        public Student Invoke(Student student)
        {
            return new Student() { Name = "jackson", Age = 20 };
        }
    }
}
