﻿using ConsoleApplication1.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceReference1.FlyServiceClient client = new ServiceReference1.FlyServiceClient();

            Console.WriteLine("调用开始:{0}", DateTime.Now);

            //client.BeginFly("hello world!", (obj) =>
            //{
            //    var myclient = (FlyServiceClient)obj.AsyncState;

            //    myclient.EndFly(obj);

            //    Console.WriteLine("调用结束");

            //}, client);

            client.FlyCompleted += (obj, e) =>
            {
                Console.WriteLine("调用结束");   
            };

            client.FlyAsync("hello,world");

            //Task.Factory.StartNew(() =>
            //{
            //    client.Fly("helle world!");
            //    Console.WriteLine("子线程访问");
            //});

            Console.WriteLine("调用完成:{0}", DateTime.Now);

            Console.Read();
        }
    }
}
