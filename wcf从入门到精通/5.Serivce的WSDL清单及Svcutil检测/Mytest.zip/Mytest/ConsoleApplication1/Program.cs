﻿
using Mytest;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            ChannelFactory<IFlyService> factory = new ChannelFactory<IFlyService>(new BasicHttpBinding(), "http://localhost:8733/MyService/");

           var channel= factory.CreateChannel();

            channel.Fly("hello world");

            Console.WriteLine("调用成功");

            factory.Close();
            
            Console.Read();
        }
    }
}
