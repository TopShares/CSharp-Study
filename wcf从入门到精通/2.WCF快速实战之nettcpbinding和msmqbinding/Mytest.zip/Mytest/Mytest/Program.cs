﻿using ClassLibrary2;
using Mytest;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

public class Class1
{
    static void Main(string[] args)
    {
        ServiceHost host = new ServiceHost(typeof(FlyService));

        host.Open();

        Console.WriteLine("WCF服务启动成功！");

        Console.Read();
    }
}
