﻿using Mytest;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Xml;

public class Class1
{
    static void Main(string[] args)
    {
        ServiceHost host = new ServiceHost(typeof(FlyService));

        host.Open();

        //将当前的地址插入到redis中
        var url = host.Description.Endpoints[0].Address.ToString();

        // insert redis
        


        Console.WriteLine("WCF 服务开启");

        Console.Read();
    }
}








