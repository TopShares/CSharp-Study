﻿using ConsoleApplication1.ServiceReference2;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using System.Web.Script.Serialization;

namespace ConsoleApplication1
{
    public class Program
    {
        static void Main(string[] args)
        {
            //从redis中随机获取一个地址
            var url = "http://192.168.1.103:8733/FlyService";


            ChannelFactory<IFlyService> factory = new ChannelFactory<IFlyService>(new BasicHttpBinding(), url);

            var channel = factory.CreateChannel();

            channel.Invoke(new Student() { });
        }
    }
}
