﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Transactions;

namespace Mytest
{
    //[ServiceBehavior]
    public class FlyService : IFlyService
    {

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = false)]
        public void Inovke(string msg)
        {
            DataClasses1DataContext context1 = new DataClasses1DataContext();

            context1.Student.InsertOnSubmit(new Student()
            {
                Name = "jack"
            });

            context1.SubmitChanges();


            DataClasses1DataContext context2 = new DataClasses1DataContext();

            context2.Student.InsertOnSubmit(new Student()
            {
                Name = "jackson"
            });

            context2.SubmitChanges();

            Console.WriteLine("服务器方法执行成功");

            OperationContext.Current.SetTransactionComplete();
        }
    }
}
