﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Mytest
{
    [ServiceBehavior(InstanceContextMode=InstanceContextMode.PerSession,ConcurrencyMode =ConcurrencyMode.Single)]
    public class FlyService : IFlyService
    {
        public int nums = 0;

        public FlyService()
        {
            Console.WriteLine("我是构造函数, threading={0},time={1} ", Thread.CurrentThread.ManagedThreadId, DateTime.Now);
        }

        public string Inovke(string msg)
        {
            Console.WriteLine("当前的nums={0},threading={1},time={2}", ++nums,Thread.CurrentThread.ManagedThreadId,DateTime.Now);

            Thread.Sleep(1000 * 5);   // 5s

            return string.Empty;
        }
    }
}
