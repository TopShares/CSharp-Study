﻿
using ConsoleApplication1.ServiceReference2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            //3个线程去执行
            Parallel.Invoke(Run, Run, Run);

            Console.Read();
        }

        static void Run()
        {
            FlyServiceClient client = new FlyServiceClient();
            client.Inovke("test");
        }
    }
}
