﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceReference2.FlyServiceClient client = new ServiceReference2.FlyServiceClient();

            //var msg = Message.CreateMessage(MessageVersion.Soap11, "http://tempuri.org/IFlyService/Inovke2", "我给服务器发送信息");

            client.Invoke("hello");

            //自定义binding，就不要自己构建message传递了，大家可以看下上面的fiddler中invoke方法的message，很复杂的
            //client.Inovke2(msg);

            //var result = client.Inovke2(msg);

            //Console.WriteLine(result.ToString());

            Console.Read();

        }
    }
}
