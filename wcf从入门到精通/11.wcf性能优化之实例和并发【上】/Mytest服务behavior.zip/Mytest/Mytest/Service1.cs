﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Mytest
{
    [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple)]
    public class FlyService : IFlyService
    {
        public int nums = 0;

        public string Inovke(string msg)
        {
            Console.WriteLine("我是服务器={0}, nums={1}", DateTime.Now, ++nums);

            return "给你数据！";
        }
    }
}
