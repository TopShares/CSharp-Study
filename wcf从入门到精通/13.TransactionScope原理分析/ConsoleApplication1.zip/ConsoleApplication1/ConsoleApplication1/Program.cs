﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Transactions;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                //using (TransactionScope scope = new TransactionScope())
                //{
                //    //开了线程去调用
                //    Parallel.Invoke(Insert1, Insert2);

                //    scope.Complete();

                //    //Insert1();

                //    //Insert2();

                //    //scope.Complete();

                //    Console.WriteLine("主tid={0}", Thread.CurrentThread.ManagedThreadId);
                //}

                for (int i = 0; i < 10; i++)
                {
                    Parallel.Invoke(Run,Run);
                }

                Console.Read();
            }
            catch (Exception ex)
            {


                throw;
            }
        }

        [ThreadStatic]
        public static int count;

        static void Run()
        {
            ++count;

            Thread.Sleep(1000);

            Console.WriteLine("tid={0}, count={1}", Thread.CurrentThread.ManagedThreadId, count);
        }

        static void Insert1()
        {
            DataClasses1DataContext context = new DataClasses1DataContext();

            context.Student.InsertOnSubmit(new Student()
            {
                Name = "jack"
            });

            context.SubmitChanges();

            Console.WriteLine("tid={0}", Thread.CurrentThread.ManagedThreadId);
        }

        static void Insert2()
        {
            DataClasses1DataContext context = new DataClasses1DataContext();

            context.Student.InsertOnSubmit(new Student()
            {
                Name = "jackson"
            });

            context.SubmitChanges();

            Console.WriteLine("tid={0}", Thread.CurrentThread.ManagedThreadId);
        }
    }
}
