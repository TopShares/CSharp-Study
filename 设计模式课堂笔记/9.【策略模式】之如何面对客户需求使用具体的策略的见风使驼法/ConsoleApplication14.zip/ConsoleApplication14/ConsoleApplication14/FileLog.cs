﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication14
{
    /// <summary>
    /// 记录日志到file的 策略
    /// </summary>
    public class FileLog : AbstractLog
    {
        public override void Write(string msg)
        {
            if (msg.Length > 10)
            {
                throw new Exception("");
            }
            //mysql,sqlserver......
            Console.WriteLine("记录日志到 File :{0}", msg);

        }
    }
}