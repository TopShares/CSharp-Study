﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication14
{
    public class StrategyContext
    {
        AbstractLog log = null;

        public StrategyContext()
        {
            log = new FileLog();
        }

        public StrategyContext(AbstractLog log)
        {
            this.log = log;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="msg"></param>
        public void Write(string msg)
        {
            try
            {
                log.Write(msg);
            }
            catch (Exception)
            {
                log = new DbLog();

                log.Write(msg);
            }
        }
    }
}