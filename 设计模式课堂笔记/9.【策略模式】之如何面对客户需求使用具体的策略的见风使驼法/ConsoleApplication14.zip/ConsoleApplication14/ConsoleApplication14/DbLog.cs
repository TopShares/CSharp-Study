﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication14
{
    /// <summary>
    /// 记录日志到db的 策略
    /// </summary>
    public class DbLog : AbstractLog
    {
        public override void Write(string msg)
        {
            //mysql,sqlserver......
            Console.WriteLine("记录日志到db :{0}", msg);

        }
    }
}