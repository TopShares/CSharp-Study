﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication18
{
    public class BuidlerDirector
    {
        AbstractPerson person = null;

        public BuidlerDirector(AbstractPerson person)
        {
            this.person = person;
        }

        //这个里面的子部件的按照一定的流程组成起来。。。
        public void CreatePerson()
        {
            this.person.CreateHead();
            this.person.CreateBody();
            this.person.CreateHand();
            this.person.CreateLeg();
        }
    }
}