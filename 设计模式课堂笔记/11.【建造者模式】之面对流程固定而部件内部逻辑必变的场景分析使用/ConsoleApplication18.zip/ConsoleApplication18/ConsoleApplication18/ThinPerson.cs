﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication18
{
    public class ThinPerson : AbstractPerson
    {
        public override void CreateBody()
        {
            //这个是部件里面的逻辑
            Console.WriteLine("瘦人的身体");
        }

        public override void CreateHand()
        {
            Console.WriteLine("瘦人的手");
        }

        public override void CreateHead()
        {
            Console.WriteLine("瘦人的头");
        }

        public override void CreateLeg()
        {
            Console.WriteLine("瘦人的脚");
        }
    }
}