﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication38
{
    class Program
    {
        static void Main(string[] args)
        {
            Composite root = new Composite() { Name = "root" };

            Composite net_tech = new Composite() { Name = "net技术" };

            net_tech.Add(new Leaf() { Name = "net新手" });
            net_tech.Add(new Leaf() { Name = "C#" });

            root.Add(net_tech);

            Composite language = new Composite() { Name = "编程语言" };

            language.Add(new Leaf() { Name = "Java" });

            root.Add(language);

            root.Display(1);
        }
    }
}
