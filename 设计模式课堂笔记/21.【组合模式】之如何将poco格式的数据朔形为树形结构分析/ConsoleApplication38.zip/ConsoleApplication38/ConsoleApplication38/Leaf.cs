﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication38
{
    public class Leaf : Component
    {
        public override void Add(Component component)
        {
            //this.children.Add(component);
        }

        public override void Remove(Component component)
        {
            //this.children.Remove(component);
        }

        public override void Display(int depth)
        {
            Console.WriteLine(new string('-', depth) + "  " + this.Name);
        }
    }
}