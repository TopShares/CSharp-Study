﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication38
{
    /// <summary>
    /// 非叶子节点
    /// </summary>
    public class Composite : Component
    {
        public override void Add(Component component)
        {
            this.children.Add(component);
        }

        public override void Remove(Component component)
        {
            this.children.Remove(component);
        }

        /// <summary>
        /// 遍历树结构
        /// </summary>
        /// <param name="depth"></param>
        public override void Display(int depth)
        {
            Console.WriteLine(new string('-', depth) + "  " + this.Name);

            //深度遍历
            foreach (var item in children)
            {
                item.Display(depth + 2);
            }
        }
    }
}