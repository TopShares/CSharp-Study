﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication3
{
    public class ZhangSan : Exam
    {

        public override string Answer()
        {
            return "A";
        }

        public override string Name
        {
            get
            {
                return "张三";
            }

        }
    }
}