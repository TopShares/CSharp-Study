﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication3
{
    public abstract class Exam
    {
        public virtual string Name { get; set; }

        public void Questions()
        {
            Console.WriteLine(string.Format("{0} 今天暖和吗？ {1}", Name, Answer()));
        }

        public virtual string Answer()
        {
            return string.Empty;
        }
    }
}