﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication3
{
    public class Lisi : Exam
    {
        public override string Name
        {
            get
            {
                return "李四";
            }
        }

        public override string Answer()
        {
            return "B";
        }
    }
}