﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication9
{
    class Program
    {
        static void Main(string[] args)
        {
            var person = new Person()
            {
                Name = "jack",
                Age = 20,
                Address = new Address()
                {
                    Province = "安徽",
                    City = "安庆"
                }
            };

            //叫做动态获取一个类的运行状态
            var person2 = (Person)person.Clone();

            person2.Address = (Address)person.Address.Clone();

            //MemoryStream ms = new MemoryStream();

            //BinaryFormatter bf = new BinaryFormatter();

            //bf.Serialize(ms, person);

            //ms.Seek(0, SeekOrigin.Begin);

            //var person2 = (Person)bf.Deserialize(ms);

            //ms.Close();

            Debug.WriteLine("执行结束");
            Console.Read();
        }
    }
}
