﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication9
{
    [Serializable]
    public class Person : ICloneable
    {
        private string name;

        private int age;

        public string Name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }

        public int Age
        {
            get
            {
                return age;
            }

            set
            {
                age = value;
            }
        }

        public Person()
        {
            Console.WriteLine("当前构造函数被执行：{0}", DateTime.Now);
        }

        public Address Address
        {
            get; set;
        }

        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }
}