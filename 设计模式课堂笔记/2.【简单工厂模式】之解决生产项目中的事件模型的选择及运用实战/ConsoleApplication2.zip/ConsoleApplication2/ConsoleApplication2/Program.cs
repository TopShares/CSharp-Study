﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Database server = new SqlLite();

            //Database server2 = new SqlLite();

            //Database server3 = new SqlLite();

            //Database server4 = new SqlLite();

            var dbtype = System.Configuration.ConfigurationManager.AppSettings["dbtype"];

            Database db1 = Factory.CreateInstance(dbtype);

            Database db2 = Factory.CreateInstance(dbtype);

            Database db3 = Factory.CreateInstance(dbtype);

            Database db4 = Factory.CreateInstance(dbtype);
        }
    }
}
