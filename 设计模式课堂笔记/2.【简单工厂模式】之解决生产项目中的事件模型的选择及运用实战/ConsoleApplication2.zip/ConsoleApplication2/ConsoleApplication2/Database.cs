﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    public abstract class Database
    {
        public abstract void Add();

        public abstract void Remove();
    }
}