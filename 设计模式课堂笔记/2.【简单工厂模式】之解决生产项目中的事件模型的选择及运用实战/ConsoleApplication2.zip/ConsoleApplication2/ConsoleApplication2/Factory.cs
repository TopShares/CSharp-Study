﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    public class Factory
    {
        public static Database CreateInstance(string dbtype)
        {
            switch (dbtype)
            {
                case "sqlserver":
                    return new SqlServer();

                case "sqlite":
                    return new SqlLite();

                case "mysql":
                    return new Mysql();
                default:
                    break;
            }

            return null;
        }
    }
}