﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication27
{
    public class Received
    {
        public void Add()
        {
            Console.WriteLine("add方法");
        }

        public void Remove()
        {
            Console.WriteLine("remove方法");
        }
    }
}