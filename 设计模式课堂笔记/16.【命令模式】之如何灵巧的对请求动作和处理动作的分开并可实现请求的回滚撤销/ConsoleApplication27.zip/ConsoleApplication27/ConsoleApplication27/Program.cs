﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication27
{
    class Program
    {
        static void Main(string[] args)
        {
            Received received = new Received();

            ICommand command = new AddCommand(received);

            ICommand command2 = new RemoveCommand(received);

            Invoker invoker = new Invoker();

            invoker.SetCommand(command);
            invoker.SetCommand(command2);

            //做撤销操作
            invoker.Undo();

            invoker.Execute();
        }
    }
}
