﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication27
{
    public class AddCommand : ICommand
    {
        Received received = null;

        public AddCommand(Received received)
        {
            this.received = received;
        }

        public void Execute()
        {
            this.received.Add();
        }
    }
}