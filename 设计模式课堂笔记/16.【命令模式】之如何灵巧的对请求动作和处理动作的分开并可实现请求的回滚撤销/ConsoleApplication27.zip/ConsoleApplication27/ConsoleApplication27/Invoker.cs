﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication27
{
    public class Invoker
    {
        private List<ICommand> commandlist = new List<ICommand>();

        public void SetCommand(ICommand command)
        {
            commandlist.Add(command);
        }

        /// <summary>
        /// 执行批量的命令
        /// </summary>
        public void Execute()
        {
            foreach (var command in commandlist)
            {
                command.Execute();
            }
        }

        /// <summary>
        /// 从命令列表中删除最后一条命令
        /// </summary>
        public void Undo()
        {
            this.commandlist.RemoveAt(this.commandlist.Count - 1);
        }
    }
}