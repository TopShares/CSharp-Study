﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication27
{
    public class RemoveCommand : ICommand
    {
        Received received = null;

        public RemoveCommand(Received received)
        {
            this.received = received;
        }

        public void Execute()
        {
            this.received.Remove();
        }
    }
}