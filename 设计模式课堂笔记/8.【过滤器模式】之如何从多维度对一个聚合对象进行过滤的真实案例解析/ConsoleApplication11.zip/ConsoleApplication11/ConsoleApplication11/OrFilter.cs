﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication11
{
    public class OrFilter : IFilter
    {
        List<IFilter> filters = new List<IFilter>();

        public OrFilter(List<IFilter> filters)
        {
            this.filters = filters;
        }

        /// <summary>
        /// 将一组filter 进行 AND 运行
        /// </summary>
        /// <param name="persons"></param>
        /// <returns></returns>
        public List<Person> Filter(List<Person> persons)
        {
            var hashset = new HashSet<Person>();

            foreach (var filterItem in filters)
            {
                var small_persons = filterItem.Filter(persons);

                //天然的过滤  hashcode
                foreach (var person in small_persons)
                {
                    hashset.Add(person);
                }
            }

            return hashset.ToList();
        }
    }
}