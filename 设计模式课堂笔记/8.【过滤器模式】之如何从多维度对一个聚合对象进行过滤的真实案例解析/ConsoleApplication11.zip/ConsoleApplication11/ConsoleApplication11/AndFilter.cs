﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication11
{
    public class AndFilter : IFilter
    {
        List<IFilter> filters = new List<IFilter>();

        public AndFilter(List<IFilter> filters)
        {
            this.filters = filters;
        }

        /// <summary>
        /// 将一组filter 进行 AND 运行
        /// </summary>
        /// <param name="persons"></param>
        /// <returns></returns>
        public List<Person> Filter(List<Person> persons)
        {
            var temp_persons = new List<Person>(persons);

            foreach (var filterItem in filters)
            {
                temp_persons = filterItem.Filter(temp_persons);
            }

            return temp_persons;
        }
    }
}