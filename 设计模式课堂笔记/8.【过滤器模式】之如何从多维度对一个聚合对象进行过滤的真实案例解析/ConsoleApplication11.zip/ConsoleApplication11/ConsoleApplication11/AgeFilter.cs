﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication11
{
    public class AgeFilter : IFilter
    {
        public List<Person> Filter(List<Person> persons)
        {
            //这个地方可以是复杂的逻辑。。。
            return persons.FindAll(i => i.Age < 20);
        }
    }
}