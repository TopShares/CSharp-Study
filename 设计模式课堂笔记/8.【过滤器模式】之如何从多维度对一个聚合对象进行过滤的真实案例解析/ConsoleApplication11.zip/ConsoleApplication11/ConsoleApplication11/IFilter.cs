﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication11
{
    public interface IFilter
    {
        List<Person> Filter(List<Person> persons);
    }
}