﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication11
{
    class Program
    {
        static void Main(string[] args)
        {
            var persons = new List<Person>();

            persons.Add(new Person() { Age = 15, Name = "mary", Email = "3333333@qq.com" });
            persons.Add(new Person() { Age = 25, Name = "mary", Email = "3333333@qq.com" });

            var filters = new IFilter[3]
            {
                 new AgeFilter(),
                 new NameFilter(),
                 new EmailFilter()
            };

            AndFilter andFilter = new AndFilter(filters.ToList());

            var list = andFilter.Filter(persons);

        }
    }
}
