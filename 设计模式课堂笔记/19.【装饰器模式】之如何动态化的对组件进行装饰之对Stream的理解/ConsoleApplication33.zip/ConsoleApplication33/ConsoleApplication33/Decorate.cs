﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication33
{
    public abstract class Decorate : Phone
    {
        Phone phone = null;

        public void SetDecorate(Phone phone)
        {
            this.phone = phone;
        }

        public override void Show()
        {
            if (this.phone != null)
            {
                this.phone.Show();
            }
        }
    }
}