﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication33
{
    public class ApplePhone : Phone
    {
        public override void Show()
        {
            Console.WriteLine("我是iphone手机");
        }
    }
}