﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication33
{
    public class Accessories : Decorate
    {
        public override void Show()
        {
            base.Show();

            //增加一些业务逻辑
            Console.WriteLine("装配中... 恭喜已经对ApplePhone进行了配件装饰");
        }

    }
}