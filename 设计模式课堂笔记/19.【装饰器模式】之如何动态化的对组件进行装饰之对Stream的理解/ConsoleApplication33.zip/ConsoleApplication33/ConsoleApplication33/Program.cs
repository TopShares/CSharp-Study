﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication33
{
    class Program
    {
        static void Main(string[] args)
        {
            //现在有手机了
            Phone phone = new ApplePhone();

            Decorate sticker = new Sticker();

            Decorate accessories = new Accessories();

            //将贴膜 装到 手机上。。。
            sticker.SetDecorate(phone);

            //将配件装到 “带有手机膜的手机上”
            accessories.SetDecorate(sticker);

            //最后将完整的手机Show一下。。。
            accessories.Show();


            //对字节的各种处理
            //Stream stream = new MemoryStream(new byte[2] { 10, 20 });

            ////压缩
            //stream = new GZipStream(stream, CompressionMode.Compress);

            ////加密
            //stream = new CryptoStream(stream, null, CryptoStreamMode.Read);

            //最终得到的stream回事什么样的？？？ stream= 压缩 +  加密

        }
    }
}
