﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication36
{
    public abstract class FlyWeight
    {
        public abstract void Run(string str);
    }
}