﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication36
{
    public class UnSharedConcreteFlyWeight : FlyWeight
    {
        public override void Run(string str)
        {
            throw new NotImplementedException();
        }
    }
}