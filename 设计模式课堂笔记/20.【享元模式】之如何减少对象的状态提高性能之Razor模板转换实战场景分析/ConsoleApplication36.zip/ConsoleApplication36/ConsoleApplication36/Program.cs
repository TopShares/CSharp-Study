﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication36
{
    class Program
    {
        static void Main(string[] args)
        {
            var flyweight1 = Factory.CreateInstance(10);

            flyweight1.Run("张三");

            var flyweight2 = Factory.CreateInstance(10);

            flyweight2.Run("李四");

        }
    }
}
