﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication36
{
    public class ConcreteFlyWeight : FlyWeight
    {
        public override void Run(string str)
        {
            Console.WriteLine("你好: {0}", str);
        }
    }
}