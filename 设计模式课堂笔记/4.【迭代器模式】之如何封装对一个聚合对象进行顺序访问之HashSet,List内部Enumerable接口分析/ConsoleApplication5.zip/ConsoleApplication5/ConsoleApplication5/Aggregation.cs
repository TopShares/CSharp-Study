﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication5
{
    /// <summary>
    /// HashSet，List  这样的一个聚合对象
    /// </summary>
    public class Aggregation
    {
        private List<int> list = new List<int>();

        public MyEnumerable GetEnumerator()
        {
            return new MyEnumerable(this);
        }

        public void Add(int num)
        {
            list.Add(num);
        }

        public int this[int index]
        {
            get
            {
                return list[index];
            }
        }

        public int Length
        {
            get
            {
                return list.Count;
            }
        }
    }
}