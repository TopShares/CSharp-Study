﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication5
{
    class Program
    {
        static void Main(string[] args)
        {
            //var list = new List<int>();

            //list.Add(10);

            //list.Add(2);

            //list.Add(5);



            ////foreach (var item in list)
            ////{
            ////    Console.WriteLine(item);
            ////}

            //var enumerator = list.GetEnumerator();

            //while (enumerator.MoveNext())
            //{
            //    Console.WriteLine(enumerator.Current);
            //}

            Aggregation aggregation = new Aggregation();

            aggregation.Add(10);
            aggregation.Add(2);
            aggregation.Add(5);

            var enumerator = aggregation.GetEnumerator();

            while (enumerator.MoveNext())
            {
                Console.WriteLine(enumerator.Current);
            }
        }
    }
}
