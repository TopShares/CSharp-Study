﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication29
{
    class Program
    {
        static void Main(string[] args)
        {
            AbstractHandler handler = new ConcreteHandler();

            AbstractHandler handler2 = new ConcreteHandler2();

            AbstractHandler handler3 = new ConcreteHandler3();

            //AbstractHandler handler4 = new ConcreteHandler();

            //这个已经组成了一个链表
            //handler.SetHandler(handler2);
            //handler2.SetHandler(handler3);

            handler.SetHandler(handler3);
            //handler4.SetHandler(handler4);

            handler.Request(10);
        }
    }
}
