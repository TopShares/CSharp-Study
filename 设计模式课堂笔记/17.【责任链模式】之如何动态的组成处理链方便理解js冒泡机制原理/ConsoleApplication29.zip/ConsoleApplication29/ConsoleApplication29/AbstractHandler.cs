﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication29
{
    public abstract class AbstractHandler
    {
        protected AbstractHandler handler = null;

        public void SetHandler(AbstractHandler handler)
        {
            this.handler = handler;
        }

        public abstract void Request(int state);
    }
}