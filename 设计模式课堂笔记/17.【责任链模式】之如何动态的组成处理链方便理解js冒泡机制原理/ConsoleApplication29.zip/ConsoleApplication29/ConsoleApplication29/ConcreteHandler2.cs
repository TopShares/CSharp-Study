﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication29
{
    public class ConcreteHandler2 : AbstractHandler
    {
        public override void Request(int state)
        {
            if (state > 3 && state <= 7)
            {
                Console.WriteLine("当前申请的天数为:{0} ,已经被研发经理同意", state);
            }
            else
            {
                if (this.handler != null)
                {
                    this.handler.Request(state);
                }
            }
        }
    }
}