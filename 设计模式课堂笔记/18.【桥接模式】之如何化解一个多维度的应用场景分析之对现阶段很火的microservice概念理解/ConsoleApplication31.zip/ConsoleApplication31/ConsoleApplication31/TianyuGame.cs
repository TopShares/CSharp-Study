﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication31
{
    public class TianyuGame : PhoneTianyu
    {
        public override void Run()
        {
            Console.WriteLine("运行 天语 的 游戏");
        }
    }
}