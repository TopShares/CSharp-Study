﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication31
{
    public class PhoneBodao : PhoneBrand
    {
        public override void Run()
        {

        }
    }
}