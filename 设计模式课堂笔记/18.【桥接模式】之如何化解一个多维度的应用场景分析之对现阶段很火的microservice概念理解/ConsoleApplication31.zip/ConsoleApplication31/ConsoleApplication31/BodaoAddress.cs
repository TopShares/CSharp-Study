﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication31
{
    public class BodaoAddress : PhoneBodao
    {
        public override void Run()
        {
            Console.WriteLine("运行 波导 的 通讯录");
        }
    }
}