﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            //PhoneBrand brand = new PhoneHuawei();  //使用华为手机

            PhoneBrand brand = new PhoneGree();

            brand.SetSoft(new Weixin());    //安装 游戏的app

            brand.Run();
        }
    }
}
