﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public class PhoneHuawei : PhoneBrand
    {
        public override void Run()
        {
            Console.WriteLine("当前正在使用 华为 手机");
            this.soft.Run();
        }
    }
}