﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public abstract class PhoneBrand
    {
        protected Soft soft = null;

        public void SetSoft(Soft soft)
        {
            this.soft = soft;
        }

        public abstract void Run();
    }
}