﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public class Weixin : Soft
    {
        public override void Run()
        {
            Console.WriteLine("正在运行  微信");
        }
    }
}