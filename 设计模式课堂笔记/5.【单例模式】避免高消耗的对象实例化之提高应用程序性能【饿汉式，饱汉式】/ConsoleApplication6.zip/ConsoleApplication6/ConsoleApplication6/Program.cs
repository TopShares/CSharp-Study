﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApplication6
{
    class Program
    {
        static void Main(string[] args)
        {
            ////new一个代价很大
            //var db = new DB();

            //db.Show();

            //db = new DB();

            //db.Show();

            //var db = DB.GetInstance();

            //db.Show();

            //db = DB.GetInstance();

            //db.Show();

            Task.Factory.StartNew(() =>
            {
                var db = DB.GetInstance();
            });

            Task.Factory.StartNew(() =>
            {
                var db2 = DB.GetInstance();
            });

            Task.Factory.StartNew(() =>
            {
                var db2 = DB.GetInstance();
            });

            Task.Factory.StartNew(() =>
            {
                var db2 = DB.GetInstance();
            });


            Console.WriteLine("主线程当前时间:{0}", DateTime.Now);
            DB.Show();

            Console.Read();

        }
    }

    public class DB
    {
        private static DB instance = null;

        private static object lockMe = new object();

        private DB()
        {
            //构造函数需要5s
            System.Threading.Thread.Sleep(2000);
        }

        public static DB GetInstance()
        {

            if (instance == null)
            {
                lock (lockMe)
                {
                    if (instance == null)
                    {
                        Console.WriteLine("线程{0}： 准备new", Thread.CurrentThread.ManagedThreadId);
                        instance = new DB();
                    }
                    else
                    {
                        Console.WriteLine("线程{0}： 当前instance有数据", Thread.CurrentThread.ManagedThreadId);
                    }
                }
            }

            return instance;
        }


        public static void Show()
        {
            Console.WriteLine("执行当前时间:{0}", DateTime.Now);
        }
    }
}
