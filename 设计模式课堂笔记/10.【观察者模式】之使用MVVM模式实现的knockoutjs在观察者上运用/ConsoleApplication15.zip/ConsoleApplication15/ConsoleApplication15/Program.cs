﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication15
{
    class Program
    {
        static void Main(string[] args)
        {
            ISubject subject = new ConcreteSubject()
            {
                SubjectState = "hello"
            };

            IObserver observer = new ConcreteObserver1(subject, "张三");
            IObserver observer2 = new ConcreteObserver2(subject, "李四");

            subject.Add(observer);
            subject.Add(observer2);

            subject.SubjectState = "天炸掉了";
            subject.Nofity();
        }
    }
}
