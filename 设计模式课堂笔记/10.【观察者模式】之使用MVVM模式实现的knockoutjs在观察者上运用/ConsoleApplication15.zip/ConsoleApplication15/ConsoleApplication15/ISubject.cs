﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication15
{
    public interface ISubject
    {
        string SubjectState { get; set; }

        void Add(IObserver observer);

        void Remove(IObserver observer);

        void Nofity();
    }
}