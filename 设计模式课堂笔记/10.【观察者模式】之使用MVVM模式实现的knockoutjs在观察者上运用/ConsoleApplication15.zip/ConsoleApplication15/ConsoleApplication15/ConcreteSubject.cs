﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication15
{
    public class ConcreteSubject : ISubject
    {
        List<IObserver> observerList = new List<ConsoleApplication15.IObserver>();

        public ConcreteSubject()
        {

        }

        public string SubjectState
        {
            get; set;
        }

        public void Add(IObserver observer)
        {
            observerList.Add(observer);
        }

        public void Remove(IObserver observer)
        {
            observerList.Add(observer);
        }

        public void Nofity()
        {
            foreach (var observer in observerList)
            {
                observer.Modify();
            }
        }
    }
}