﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication15
{
    public class ConcreteObserver2 : IObserver
    {
        ISubject subject = null;

        string name = string.Empty;

        public ConcreteObserver2(ISubject subject, string name)
        {
            this.subject = subject;
            this.name = name;
        }

        public void Modify()
        {
            Console.WriteLine("{0}被修改, {1} 做出了反应", subject.SubjectState, this.name);
        }
    }
}