﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication20
{
    public class SqlserverFactory : IFactory
    {
        public IUser CreateInstance()
        {
            return new SqlserverUser();
        }
    }
}