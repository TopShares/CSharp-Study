﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication20
{
    public class SqlLiteUser : IUser
    {
        public void Add()
        {
            Console.WriteLine("sqllite 的 add");
        }

        public void Remove()
        {
            Console.WriteLine("sqllite 的 remove");
        }
    }
}