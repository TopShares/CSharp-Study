﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication20
{
    class Program
    {
        static void Main(string[] args)
        {
            //IUser user = Factory.CreateInstance("sqllite");

            //user.Add();

            IFactory factory = new MongodbFactory();

            var user = factory.CreateInstance();

            user.Remove();


            //
            var factory1 = new MongodbFactory();

            var factory2 = new MongodbFactory();

            var factory3 = new MongodbFactory();

            var factory4 = new MongodbFactory();

            var factory5 = new MongodbFactory();
        }
    }
}
