﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication20
{
    public class SqlliteFactory : IFactory
    {
        public IUser CreateInstance()
        {
            return new SqlLiteUser();
        }
    }
}