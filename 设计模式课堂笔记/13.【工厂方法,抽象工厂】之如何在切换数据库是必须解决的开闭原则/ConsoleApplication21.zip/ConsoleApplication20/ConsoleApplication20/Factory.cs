﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication20
{
    public class Factory
    {
        public static IUser CreateInstance(string type)
        {
            switch (type)
            {
                case "sqlserver":
                    return new SqlserverUser();
                case "sqllite":
                    return new SqlLiteUser();
                default:
                    break;
            }

            return null;
        }
    }
}