﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication20
{
    public class SqlliteFactory : IFactory
    {

        public IUser CreateUserInstance()
        {
            return new SqlLiteUser();
        }

        public IOrder CreateOrderInstance()
        {
            return new SqlLiteOrder();
        }
    }
}