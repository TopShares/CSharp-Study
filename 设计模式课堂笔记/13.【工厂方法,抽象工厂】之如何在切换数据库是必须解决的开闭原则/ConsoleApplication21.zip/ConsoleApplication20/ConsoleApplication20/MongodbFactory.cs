﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication20
{
    public class MongodbFactory : IFactory
    {
        public IUser CreateUserInstance()
        {
            return new MongodbUser();
        }

        public IOrder CreateOrderInstance()
        {
            return new MongodbOrder();
        }
    }
}