﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication20
{
    public class SqlserverUser : IUser
    {
        public void Add()
        {
            Console.WriteLine("sqlserver 的 add");
        }

        public void Remove()
        {
            Console.WriteLine("sqlserver 的 remove");
        }
    }
}