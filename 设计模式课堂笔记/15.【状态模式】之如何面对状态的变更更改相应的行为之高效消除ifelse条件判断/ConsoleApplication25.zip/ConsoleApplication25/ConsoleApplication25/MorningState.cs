﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication25
{
    public class MorningState : AbstractState
    {
        public override void Handler(Context context)
        {
            if (context.Hours > 0 && context.Hours < 12)
            {
                Console.WriteLine("早上好");
            }
            else
            {
                context.State = new NoonState();

                context.Request();
            }
        }
    }
}