﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication24
{
    public class ConcreteState1 : AbstractState
    {
        public override void Handler(Context context)
        {
            context.State = new ConcreteState2();
        }
    }
}