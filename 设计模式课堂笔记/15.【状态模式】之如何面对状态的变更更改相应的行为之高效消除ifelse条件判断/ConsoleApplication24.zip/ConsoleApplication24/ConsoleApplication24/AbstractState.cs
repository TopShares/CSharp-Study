﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication24
{
    public abstract class AbstractState
    {
        public abstract void Handler(Context context);
    }
}