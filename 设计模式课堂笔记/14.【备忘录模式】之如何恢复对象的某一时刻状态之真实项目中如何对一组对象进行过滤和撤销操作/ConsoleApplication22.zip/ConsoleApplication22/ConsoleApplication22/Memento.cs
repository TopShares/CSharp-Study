﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication22
{
    public class Memento
    {
        public List<int> CustomerList
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public int LeafletID
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }
    }
}