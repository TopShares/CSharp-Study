﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication22
{
    public class Caretaker
    {
        public List<Memento> MementoList
        {
            get; set;
        } = new List<Memento>();
    }
}