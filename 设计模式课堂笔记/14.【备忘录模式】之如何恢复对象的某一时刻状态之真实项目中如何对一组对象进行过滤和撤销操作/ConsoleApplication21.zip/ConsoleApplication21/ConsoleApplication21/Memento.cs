﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication21
{
    public class Memento
    {
        public string State
        {
            get; set;
        }
    }
}