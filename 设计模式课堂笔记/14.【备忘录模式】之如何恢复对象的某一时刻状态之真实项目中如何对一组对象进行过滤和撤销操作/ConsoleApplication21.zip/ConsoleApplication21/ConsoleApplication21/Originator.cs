﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication21
{
    public class Originator
    {
        public string State
        {
            get; set;
        }

        public string State2
        {
            get; set;
        }

        /// <summary>
        /// 创建备份录：【生成快照的方法】
        /// </summary>
        public Memento CreateMemento()
        {
            return new Memento() { State = this.State };
        }

        public void RecoveryMemento(Memento memento)
        {
            this.State = memento.State;
        }
    }
}