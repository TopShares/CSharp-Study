﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication21
{
    class Program
    {
        static void Main(string[] args)
        {
            Originator originator = new Originator()
            {
                State = "张三",
                State2 = "你好"
            };

            Console.WriteLine("原始值:{0}", originator.State);

            Caretaker caretaker = new Caretaker()
            {
                memento = originator.CreateMemento()
            };

            //修改
            originator.State = "李四";
            Console.WriteLine("修改后的值:{0}", originator.State);

            Console.WriteLine(originator.State);

            //现在要撤销了。。。。
            originator.RecoveryMemento(caretaker.memento);

            Console.WriteLine("赋值错误，正在修复中:{0}", originator.State);

            //重新输出
            Console.WriteLine(originator.State);
            Console.WriteLine("修改完毕 {0}", originator.State);
        }
    }
}
