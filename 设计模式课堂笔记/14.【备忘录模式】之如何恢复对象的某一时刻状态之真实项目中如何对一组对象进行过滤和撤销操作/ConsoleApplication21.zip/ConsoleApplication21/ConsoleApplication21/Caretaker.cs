﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication21
{
    public class Caretaker
    {
        public Memento memento
        {
            get; set;
        }
    }
}