﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication10
{
    public class SqlServer : AbstractDatabase
    {
        public override void Add()
        {
            //可能非常复杂。。。【跨机器】
            Console.WriteLine("sqlserver  的 add操作");
        }

        public override void Remove()
        {
            Console.WriteLine("sqlserver  的 remove操作");
        }
    }
}