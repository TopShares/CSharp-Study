﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication10
{
    public abstract class AbstractDatabase
    {
        public abstract void Add();

        public abstract void Remove();
    }
}