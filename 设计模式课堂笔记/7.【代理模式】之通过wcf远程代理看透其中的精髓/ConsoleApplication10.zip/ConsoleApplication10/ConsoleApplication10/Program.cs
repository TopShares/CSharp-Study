﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication10
{
    class Program
    {
        static void Main(string[] args)
        {
            //Proxy proxy = new Proxy();

            //proxy.Add();

            ServiceReference1.Service1Client client = new ServiceReference1.Service1Client();//proxy

            var msg = client.DoWork("张三");

            Console.WriteLine(msg);

            Console.Read();
        }
    }
}
