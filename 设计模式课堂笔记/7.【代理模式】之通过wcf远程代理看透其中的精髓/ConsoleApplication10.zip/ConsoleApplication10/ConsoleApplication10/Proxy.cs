﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication10
{
    public class Proxy : AbstractDatabase
    {
        SqlServer sqlserver = new SqlServer();

        public override void Add()
        {
            sqlserver.Add();
        }

        public override void Remove()
        {
            sqlserver.Remove();
        }
    }
}